'use strict'

const express = require('express')
const api = express.Router()
const billController = require('../bill/bill.controller')
const { ensureAuth, isAdmin, isClient} = require('../services/authenticated')

api.get('/getBills/:id', [ensureAuth, isAdmin], billController.getBills)
api.get('/products/:id', [ensureAuth, isAdmin], billController.billProducts)
api.put('/update/:id', [ensureAuth, isAdmin], billController.update)

module.exports = api;