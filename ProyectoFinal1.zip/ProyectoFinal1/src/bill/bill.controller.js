'use strict'

const User = require('../user/user.model')
const Bill = require('./bill.model')
const Product = require('../product/product.model')
const infoUser = '-_id username phone'
const infoProduct = '-_id name price'
const infoBill = '-_id -products._id'
const {validateData} = require('../utils/validate')

exports.buy = async(req, res)=>{
    try{
        //Obtener el id del usuario para crea su factura
        let userId = req.user.sub
        let user = await User.findOne({_id: userId})

        //Revisar si hay algun producto que no tenga stock
        let cart = user.cart
        for(let productCart of cart){
            let existStock = await Product.findOne({_id: productCart.product})
            if(existStock.stock < productCart.amount) return res.send({message: 'You can not compare this product'+ productCart.product +'because there is no stock'})
        }

        //Validar el stock 
        for(let productCart of cart){
            let product = await Product.findOne({_id: productCart.product})
            let stock = product.stock - productCart.amount
            let updateStock = await Product.findOneAndUpdate({_id: productCart.product},{stock: stock})
        }

        //Generar factura 
        let data = req.body
        let params = {
            user: userId,
            nit: data.Nit,
            products: user.cart,
            date: Date.now(),
            total: user.totalCart
        }
        let bill = new Bill(params)
        let newBill = await bill.save()
        
        let myBill = await Bill.findById({_id: newBill._id})
            .populate('user', infoUser)
            .populate('products.product', infoProduct)
            .select(infoBill)

        //Vaciar el carrito
        let totalCart = 0, cartVacio = []
        await User.findOneAndUpdate({_id: userId},{ totalCart: totalCart, cart: cartVacio },{new: true})

        return res.send({message:'Thanks for your purchase', myBill})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error a la hora de comprar el carrito'})
    }
}

exports.getBills = async(req, res)=>{
    try{
        let userId = req.params.id;
        let myBills = await Bill.find({user: userId})
            .populate('user', infoUser)
            .populate('products.product', infoProduct)
            .select(infoBill)
        
        if(!myBills) return res.send({message: 'this user does not exist or you do not have invoices'})
        return res.send({message: 'Your bills', myBills})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error a la hora de retornar las facturas'})
    }
}

exports.billProducts = async(req, res)=>{
    try{
        let billId = req.params.id

        let bill = await Bill.findOne({_id: billId})
            .populate('products.product', '-stock -sales')
            .select('-user -nit -date -products._id')
        return res.send({message: bill})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error al buscar los productos por producto'})
    }
}

exports.update = async(req, res)=>{
    try{
        //obtener los valores 
        let billId = req.params.id
        let data = req.body
        let amount = 0
        let total = 0

        //verifica que no vengan datos vacios 
        let params = {
            password: data.product,
            role: data.amount
        }
        let validate = validateData(params)
        if(validate) return res.status(400).send(validate)

        //verifacar que existan los productos en la factura 
        let bill = await Bill.findOne({_id: billId, "products.product": data.product})
        if(!bill) return res.send({message: 'El producto no existe en los productos de la factura'}) 
        let product = await Product.findOne({_id: data.product})
        
        //buscar la cantidad del producto en la factura 
        for(let product of bill.products){
            if(product.product == data.product) amount = product.amount
        }
        
        //Verificar stock
        if(data.amount > amount) total = product.stock - (data.amount - amount)
        if(data.amount < amount) total = product.stock + (amount - data.amount)
        if(data.amount == amount) total = product.stock

        //actualizar los datos 
        let updateBill = await Bill.findOneAndUpdate(
            {_id: billId},
            {$set: {products: {amount: data.amount, product: data.product}}},
            {new: true}
        )
        
        let updateStock = await Product.findOneAndUpdate(
            {_id: data.product},
            {stock: total},
            {new: true}
        ).select('stock')

        return res.send({message: updateBill, updateStock})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error al actualizar la factura'})
    }
}

/*exports.deleteProduct = async(req, res)=>{
    try{
        //obtener los datos 
        let billId = req.params.id
        let productId = req.body.product
        let amount = 0
        let total = 0
        
        //Veficar que el producto existe en la factura
        let bill = await Bill.findOne({_id: billId, "products.product": productId},{new: true})
        if(!bill) return res.send({message: 'El producto o la factura no existen'}) 
        let product = await Product.findOne({_id: productId})

        //Encontrar el valor del stock
        for(let product of bill.products){
            if(product.product == productId) amount = product.amount
        }
        total = product.stock + amount

        //Eliminar el producto de la factura 
        await Bill.updateOne(
            {_id: billId},
            {$pull: { products: {product: productId}}},
        )
        //actualizar el stock
        let stock = await Product.findOneAndUpdate(
            {_id: productId},
            {stock: total},
            {new: true}
        ).select('stock')

        return res.send({message:'Se ha eliminado el producto exitosamente', stock})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error al eliminar el producto de la factura'})
    }
}*/