'use strict'

const User = require('./user.model');
const Bill = require('../bill/bill.model')
const infoUser = '-_id username phone'
const infoProduct = '-_id name price'
const infoBill = '-_id -products._id'
const {validateData, encrypt, checkPassword} = require('../utils/validate');
const { createToken } = require('../services/jwt')

//Esta funcion solo va a ser accesible por los usuario logeados 
exports.test = (req, res)=>{
    res.send({message: 'Text function is running'})
}

exports.register = async(req, res)=>{
    try{
        //Capturar el formulario de registro (Body)
        let data = req.body;
        data.totalCart = 0
        let params = {
            password: data.password,
            
        }
        let validate = validateData(params)
        if(validate) return res.status(400).send(validate)
        //Role predefinido
        data.role = 'CLIENT'
        //Encriptar contraseña
        data.password = await encrypt(data.password)
        //Guardar la informacion
        let user = new User(data);
        await user.save();
        return res.send({message: 'Account created sucessfully'})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error creating account', error: err.message})
    }
}

exports.save = async(req, res)=>{
    try{
        //capturar datos
        let data = req.body;
        let params = {
            password: data.password,
            role: data.role
        }
        let validate = validateData(params)
        if(validate) return res.status(400).send(validate)
        //encriptar la password
        data.password = await encrypt(data.password)
        // guardar
        let user = new User(data);
        await user.save();
        return res.send({message: 'Account created sucessfully'})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'error saving user', error: err.message})
    }
}

exports.login = async(req, res)=>{
    try{
        //Obtener la data a validar (username and password)
        let data = req.body;
        let credentials = {//los datos obligatorio que va a validar la funcion data 
            username: data.username,
            password: data.password
        }
        let msg = validateData(credentials);
        if(msg) return res.status(400).send(msg)
        //Validar si existe en la DB
        let user = await User.findOne({username: data.username});
        //Validar la contrase;a
        if(user && await checkPassword(data.password, user.password)){
            let token = await createToken(user)
            return res.send({message: 'User logged sucessfully', token})
        }   
        return res.status(401).send({message: 'Invalid credentials'});
        //Retornar un mensaje de logeo junto a un token
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error, not logged'})
    }
}

exports.updateUser = async (req, res) => {
    let data = req.body;

    if(!data.password){
        try {
            let userId = req.params.id;
            let updateUser = await User.findOneAndUpdate(
                { _id: userId },
                data, 
                { new: true });
            if (!updateUser) return res.status(404).send({ message: 'User not afound and update' });
                return res.send({ updateUser });
        }catch (err) {
            console.error(err);
            return res.status(500).send({ message: 'Error Updated User ' })
        }   
    }else{
        return res.send({message: 'Cant update password'})
    }

}

exports.deleteUser = async(req, res)=>{
    try{
        let userId = req.params.id;
        let existUser = await User.findOne({_id: userId})
        if(!existUser){
            return res.send({message: 'User does not exist'})
        }else{
        let deleteUser = await User.findOneAndDelete({_id: userId})
        return res.send({message: 'Your user has been deleted'})    
    }
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error Deleting'})
    }
}