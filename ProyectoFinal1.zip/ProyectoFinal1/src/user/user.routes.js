'use strict'

const express = require('express');
const api = express.Router();
const userController = require('./user.controller')
const { ensureAuth, isAdmin, isClient } = require('../services/authenticated')

//Ruta de testeo
api.get('/test', [ensureAuth, isAdmin], userController.test)
//Rutas publicas
api.post('/login', userController.login)
api.post('/register', userController.register)

//Rutas privadas
api.put('/update/:id', ensureAuth, userController.updateUser)
api.delete('/delete/:id', ensureAuth, userController.deleteUser)

//rutas privadas solo para administrador 
api.post('/save', [ensureAuth, isAdmin], userController.save);


//api.put('/update/:id', [ensureAuth, isAdmin], userController.updateUser)
//api.delete('/delete/:id', [ensureAuth, isAdmin], userController.deleteUser)


module.exports = api;