'use strict'

const express = require('express');
const api = express.Router();
const productController = require('../product/product.controller')
const billController = require('../bill/bill.controller')
const { ensureAuth, isAdmin, isClient} = require('../services/authenticated')

api.get('/test', productController.test)

//rutas para clientes
api.get('/getProduct/:id',[ensureAuth, isClient], productController.getProduct)
api.get('/masVendido', [ensureAuth, isClient], productController.masVendido)
api.get('/getProductName', [ensureAuth, isClient], productController.getProductName)
api.get('/getProductCategory/:id', [ensureAuth, isClient], productController.getProductCategory)
api.post('/addProductCart/:id',[ensureAuth, isClient], productController.addProductCart)
//carrito
api.post('/buy', billController.buy)

//rutas para admins
api.get('/getProduct/:id',[ensureAuth, isAdmin], productController.getProduct)
api.post('/add',[ensureAuth, isAdmin], productController.addProduct)
api.get('/fueraProduct', [ensureAuth, isAdmin], productController.fueraProduct)
api.delete('/delete/:id', [ensureAuth, isAdmin], productController.delete)
api.get('/update/:id', [ensureAuth, isAdmin], productController.update)
api.get('/masVendido', [ensureAuth, isClient, isAdmin], productController.masVendido)
api.get('/getProductName', [ensureAuth, isAdmin], productController.getProductName)
api.get('/getProductCategory/:id', [ensureAuth, isAdmin], productController.getProductCategory)



module.exports = api;