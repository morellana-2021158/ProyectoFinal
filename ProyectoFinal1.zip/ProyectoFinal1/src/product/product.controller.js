'use strict'

const Product = require('../product/product.model')
const Category = require('../category/category.model')
const User = require('../user/user.model')
const { find } = require('../product/product.model')

exports.test = async(req, res)=>{
    return res.send({message: 'test is running'})
}

exports.addProduct = async(req, res)=>{
    try{
        let data = req.body

        let categoryExist = await Category.findOne({_id: data.category})
        if(!categoryExist) return res.send({message: 'the category does not exist'})

        let product = new Product(data)
        await product.save()

        return res.send({message: 'I have saved the product'})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error saving product', error: err.message})
    }
}

exports.addProductCart = async(req, res)=>{
    try{
        let userId = req.user.sub
        let productId = req.params.id
        let amountProduct =0
        let total =0

        //veficar si existen los datos
        let product = await Product.findOne({_id: productId})
        let user = await User.findOne({_id: userId})
        let totalCart = user.totalCart
        if(!product) return res.send({message: 'el producto no existe'})
        
        //verificar que el producto exista en el carrito 
        let existProductCart = await User.findOne({ _id: userId, "cart.product": productId});
        if(existProductCart){
            let cart = existProductCart.cart
            for(let productCart of cart) {
                if(productCart.product == productId)
                amountProduct = productCart.amount
            }
            // Agregar un producto existente al carrito de compras
            amountProduct = amountProduct+1

            let updateCart =  await User.updateOne(
                {_id: userId, "cart.product": productId},
                {$set: { "cart.$.amount": amountProduct}},
            )
            //Actualizar stock
            total = totalCart + product.price
            let updateUser = await User.findOneAndUpdate({_id: userId},{totalCart: total})
            let cartNew = updateUser.cart
            if(!updateCart) return res.send({message: 'could not save product in cart'})
            return res.send({message: 'The product was saved in the cart and the amount was added', cartNew})
        }

        //Agregar un producto que no existe al carrito de compras
        let cart = await User.updateOne(
            {_id: userId},
            {$push: {cart: {product: productId, amount: 1}}}
        )

        //Actualiza la suma total de la compra
        total = totalCart + product.price
        await User.findOneAndUpdate({_id: userId}, {totalCart: total})
        
        if(!cart) return res.send({message: 'could not save product in cart'})
        return res.send({message: 'se guardo el producto en carrito'})

    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error al agregar un producto al carrito', error: err.message})
    }
}


exports.getProductCategory = async(req, res)=>{
    try{
        let category = req.params.id
        
        let existCategory = await Category.findOne({_id: category})
        if(!existCategory) return res.send({message: 'The category does not exist'})

        let products = await Product.find({category: category})
        res.send({message: products})        
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error when obtaining the products by categories'})
    }
}

exports.getProduct = async(req,res)=>{
    try{
        let productId = req.params.id
        let productExist = await Product.findOne({_id: productId})
        if(!productExist) return res.send({message: 'product does not exist'})
        res.send({message: productExist})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error getting the product'})
    }
}

exports.getProductName = async(req, res)=>{
    try{
        let data = req.body

        let existProduct = await Product.findOne({name: data.name})
        if(!existProduct) return res.send({message: 'product does not exist'})
        return res.send({message: existProduct})

    }catch(err){
        console.error(err)
        return res.status(500).send({message: ' Error a la hora de mostrar producto'})
    }
}

exports.update = async(req, res)=>{
    try{
        let productId = req.params.id
        let data = req.body
        let categoryExist = await Category.findOne({_id: data.category})
        if(!categoryExist) return res.send({message: 'No existe la categoria'})

        let updatedProduct = await Product.findOneAndUpdate(
            {_id: productId},
            data,
            {new: true}
        ).populate('category')

        if(!updatedProduct) return res.send({message: 'The category does not exist'})
        return res.send({message: updatedProduct})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error when updating product', error: err.message})
    }
}

exports.fueraProduct = async(req, res)=>{
    try{
        let product = await Product.find({stock: 0}).populate('category')
        res.send({message: product})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error a la hora de mostra productos agotados'})
    }
}

exports.masVendido = async(req, res)=>{
    try{
        let products = await Product.find().sort({sales: -1})
        res.send({message: products})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error a la hora de mostrar los productos mas vendidos'})
    }
}

exports.delete = async(req, res)=>{
    try{
        let productId = req.params.id

        let deleteProduct = await Product.findOneAndDelete({_id: productId})
        if(!deleteProduct) return  res.send({message:'el producto no existe'})
        return res.send({message: 'Se a eliminado exitosamente'})
    }catch(err){
        console.error(err)
        return res.status(500).send({message: 'Error a la hora de eliminar'})
    }
}