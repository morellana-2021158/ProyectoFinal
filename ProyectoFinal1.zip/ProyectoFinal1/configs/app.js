'use strict'

const express = require('express')
//Logs de la solicitudes que recibe el servidor 
const morgan = require('morgan')
//aplica Seguridad basica del servidor 
const helmet = require('helmet')
//Aceptacion de solicitudedes desde otro sistema o desde la misma maquina
const cors = require('cors')
const { Router } = require('express')
//Intancia de express
const app = express();
const port = process.env.PORT || 3000;
const userRoutes = require('../src/user/user.routes')
const categoryRoutes = require('../src/category/category.routes')
const categoryController = require('../src/category/category.controller')
const productRoutes = require('../src/product/product.routes')
//const categoryController = require('../src/category/category.controller')
//configurar el servidor http de express
app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(morgan('dev'));//combined o dev
app.use('/user', userRoutes);
app.use('/category', categoryRoutes);
app.use('/product', productRoutes);

exports.initServer = ()=>{
    app.listen(port)
    console.log(`Server http running in port ${port}`);
    categoryController.defaultCategory()
}